# Android-project

This is a Hotel booking app created by using android studio.The app allows users to login into the application to view facilities available at the hotel.It also allows the user to view different type of rooms available as well as their current rates.Users can book any number of rooms they want on the basis of their preferences.

The hotel administration stores details of each user who logs into the app with the help of a database.Database consits of a table which stores data about which rooms are occupied and by whom.Once the occupants of the room leave that particular row in the table gets deleted.

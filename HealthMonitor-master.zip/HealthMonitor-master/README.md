# HealthMonitor
HealthMonitor android app was built for a final year project that involves automatic monitoring of a patient's app, hereby bringing mobile inteligence to health system.

# Smart Weather App
This is a **weather forcasting** application. When any user download this application he or she will get directily his/ her locaiton weather forecast. Also user can search any location and get next 3 days weather forcast. This Application have modern splash screen and home page (modern UI). Also this Application is Responsive.
# Used Technology
 - Fast Android Networking
 - Weather Api
 - Java Programming Language
 - Picasoo 
 - Facebook Shimmer Effect

# Preview of Application


![fr_project](https://user-images.githubusercontent.com/89797141/185447958-30d3bf40-b768-42d0-aadd-876b39e6edc3.jpg)

# Dowbload 

![playStore](https://user-images.githubusercontent.com/89797141/210098886-b3cc3319-8c38-4a31-a406-f7d58f10ae0c.png)

[Download](https://play.google.com/store/apps/details?id=com.smartweather.smartweather)
